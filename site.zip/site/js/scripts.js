// 1.
function isAnagram(s1, s2){
  return s1.split("").sort().join("") === s2.split("").sort().join("");
}

console.log(isAnagram("state", "taste"));
console.log(isAnagram("fold", "bold"));



// 2.
function overThirty(people){
  var people = [ { name: 'Jon', age: 31 }, { name: 'Ned', age: 53 }, { name: 'Brandon', age: 25 }, { name: 'Arya', age: 27 }, { name: 'Sansa', age: 30 }, { name: 'Robb', age: 32 } ];
  var peopleOverThirty = [];
  var arrayLength = people.length;

  for (var i = 0; i < arrayLength; i++) {
      //console.log(people[i].age);
      //console.log(people[i].name);
      if (people[i].age > 30) {
        //console.log(people[i].name);
        var names = people[i].name;
        //peopleOverThirty.push(names);
        //console.log(names);
        //return peopleOverThirty;
        peopleOverThirty.push(names);
      }
  }
  return peopleOverThirty;
};

console.log(overThirty());




// 3.
function calcHypotenuse(x, y){
  return Math.sqrt(x*x + y*y)
}

console.log(calcHypotenuse(3, 4));
console.log(calcHypotenuse(10, 24));
