/* Anagrams */
console.log("Unfortunately not exactly bonus like behind the scene bloopers. Basically the same stuff as the front-end, but less pretty. \n ")

console.log("Enter your potential anagram words into the page to output to the console. \n ")

function findAnagram(){
    let input1 = document.getElementById("word1").value,
        input2 = document.getElementById("word2").value,
        results = document.getElementById("results");
    let word1 = input1.length,
        word2 = input2.length;
    
    if(word1 !== word2){
        console.log('Hint: Try words with the same number of letters');
        results.innerText =  "Words are not the same length"
        return
    }
    let str1 = input1.split('').sort().join('');
    let str2 = input2.split('').sort().join('');
    if(str1 === str2){
        console.log("True: Anagrams");
        results.innerText =  "Yes! These are anagrams."
    } else { 
        console.log("False: Not Anagrams");
        results.innerText =  "Nope, not an anagram."
    }
}



/* Age Filter */

const people = [ 
    { name: 'Jon', age: 31 }, 
    { name: 'Ned', age: 53 }, 
    { name: 'Brandon', age: 25 }, 
    { name: 'Arya', age: 27 }, 
    { name: 'Sansa', age: 30 }, 
    { name: 'Robb', age: 32 },
    { name: 'Ivy', age: 23 },
    { name: 'George', age: 66 },
    { name: 'Queen Elizabeth', age: 95 },
]

const minAge = 30;
const minAgeArray = (people) => {
  const ageFilter = [];
  const above30Array = [];
  for (let i = 0; i < people.length; i++) {
    if ((people[i].age > minAge)) {
        ageFilter.push(people[i])} 
    else {
        above30Array.push(people[i]); 
    }
  }
    return ageFilter;
};

console.log(`These people have lived for at least 30 earthly revolutions:`)
let ageOutput = minAgeArray(people);

for (let i = 0; i < ageOutput.length; i++) {
    console.log(ageOutput[i]); 
}

let ageList = document.getElementById("age");
ageOutput.forEach((human)=>{
    let li = document.createElement("li");
    li.innerText = human['name'];
    ageList.appendChild(li);
  })




/* Yay for calculators & functions */

let ht = document.getElementById("height"),
    lg = document.getElementById("length"),
    answer = document.getElementById("answer");

ht.addEventListener('input', hypo);
lg.addEventListener('input', hypo);

function hypo() {
    let x = parseFloat(ht.value) || 0;
    let y = parseFloat(lg.value) || 0;

    let htSquare = x ** 2;
    let lgSquare = y ** 2;
    let sum = htSquare + lgSquare;
    let hypo = Math.sqrt(sum);
    answer.innerText =  hypo
}

let findHypotenuse = (a, b) => {
    const htSquare = a ** 2;
    const lgSquare = b ** 2;
    const c = htSquare + lgSquare;
    const hypotenuse = Math.sqrt(c);
    console.log(`\n The hypotenuse of a triange with a height of ` + a + ` and a base of `+ b + ` is: ` + hypotenuse);
 };

 findHypotenuse(4, 7)

console.log('\n')